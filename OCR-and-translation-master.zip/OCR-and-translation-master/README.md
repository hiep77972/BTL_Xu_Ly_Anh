# OCR-and-translation

This program will open an image and use tesseract software to performing OCR and translate library to translate the word.


References:

https://www.pyimagesearch.com/
https://pypi.org/project/translate/
